"use strict";

///////////////////////////////////////////
// 
//SPACE INVADERS
//Problème récurrent concernant mes innerHTML, non reconnu par internet explorer à cause des ``
//La solution serait d'utiliser appendChild, addClass et createElement. Je le ferai après NodeJS et ExpressJS
//Le jeu peut forcément être améliorer, j'aurai souhaité ajouter la fonction de tir pour les ennemis
//j'ai très mal commencé mon jeu par rapport à la logique et j'ai surement vu trop grand 
//
///////////////////////////////////////////


///////////////////////////////////////////
//VARIABLES GLOBALES           
///////////////////////////////////////////

var pressEnter = window.document.getElementById('go');
var tuton = window.document.getElementById('tuto');
var sens = true;
var boolo = true;
var momo=false;
var keyEtat = {};
var score = 0;
var vitesseVaisseau = 5;
var topEShip = 450;
var opacity1 = 0;
var fontSize1 = 0;
var opacity2 = 0;
var fontSize2 = 0;
var compteur = 0;
var compteurTop = 0;
var intervalID;
var spaceshipTableau = {
    tableauPos: ["url('sprites/spaceship/spaceship.png')", "url('sprites/spaceship/spaceshipLeftOne.png')", "url('sprites/spaceship/spaceshipLeftTwo.png')", "url('sprites/spaceship/spaceshipRightOne.png')", "url('sprites/spaceship/spaceshipRightTwo.png')"],
    left: 384,
    top: 430,
};


//Lancer le jeu après le tutoriel

var notutorial = function(){
    if(boolo == true){
        intervalID = setInterval(spaceInvadersLap, 1000/60);
    }
};


//Condition de victoire

//Animation du texte WINNER 
var winner = window.document.getElementById('win');
var win = function() {
    if(opacity1 <= 1){
      opacity1 = opacity1 + 0.01;
    }
    if(fontSize1 <= 275){
        fontSize1 = fontSize1 + 1.5;
    }
    winner.style.fontSize = fontSize1 + 'px';
    winner.style.opacity = opacity1;
};

//Lorsque condition victoire respectée, relance tout le script, et tutoriel remit au premier plan
var winning = function(){
    document.location.reload(true);
    boolo = true;
    tuton.style.zIndex = "1";
};

//Fonction de scoring : ajout du score en js, lorsque score = 5 vitesse du vaisseau mère diminue, 
//lorsque score = 10 diminue encore et lorsque le score arrive à 15, stop le jeu, apparition du 
//texte WINNER, ouverture du pdf dans une autre page web et utilisation de la fonction winning ci-dessus 
var scoring = function(){
    var scoring = window.document.getElementById("score");
    scoring.innerHTML = "Score : " + score;
    if(score == 5){
        vitesseVaisseau = 3;
    }
    if(score == 10){
        vitesseVaisseau = 2.5;
    }
    if(score == 15){
        clearInterval(intervalID);
        setInterval(win, 15);
        setTimeout(ouvrirLien, 2500);
        setTimeout(winning, 2700);
    }
};

//Fonction ouverture du pdf dans un nouvel onglet
function ouvrirLien(){
	if(!momo){
		var link = "sprites/demaria.pdf";
		open(link,"_blank");
		momo = true;
	}
	
}


//CREATION ENNEMIS

var tempEnnemi = function(name,posx,posy){
    this.name = name;
    this.x = posx;
    this.y = posy;
    this.alive = true; //utiliser dans mes collisions
}

var Ennemy = function(src, pos){ //fonction constructeur
    this.src = src;
    this.pos = pos;
    this.width = 64;
    this.height = 64;
    this.myShip = {};
    this.draw = function(){ //dessin ennmis en leur ajoutant une div pour chaque ligne d'ennemis avec une classe et un style
        this.src.innerHTML = "";
        for(var i = 0; i < this.pos.length; i++){
            if(this.src == window.document.getElementById("eShipOne")){
                this.src.innerHTML += `<div class="eSpaceshipOne" style="left:${this.pos[i].left}px;"></div>`;
                this.tabEnnemi.push({x: parseInt(this.pos[i].left),y: parseInt(this.pos[i].top)});
                this.myShip['eShipOneenema' + i] = new tempEnnemi('enema' + i,this.pos[i].left,this.pos[i].top);
                this.myShip['eShipOneenema' + i].x = this.myShip['eShipOneenema' + i].x + compteur;
            }
            if(this.src == window.document.getElementById("eShipTwo")){
                this.src.innerHTML += `<div class="eSpaceshipTwo" style="left:${this.pos[i].left}px;"></div>`;
                this.tabEnnemi.push({x: parseInt(this.pos[i].left),y: parseInt(this.pos[i].top)});
                this.myShip['eShipTwoenema' + i] = new tempEnnemi('enema' + i,this.pos[i].left,this.pos[i].top)
                this.myShip['eShipTwoenema' + i].x = this.myShip['eShipTwoenema' + i].x + compteur;
            }
            if(this.src == window.document.getElementById("eShipThree")){
                this.src.innerHTML += `<div class="eSpaceshipThree" style="left:${this.pos[i].left}px;"></div>`;
                this.tabEnnemi.push({x: parseInt(this.pos[i].left),y: parseInt(this.pos[i].top)});
                this.myShip['eShipThreeenema' + i] = new tempEnnemi('enema' + i,this.pos[i].left,this.pos[i].top)
                this.myShip['eShipThreeenema' + i].x = this.myShip['eShipThreeenema' + i].x + compteur;
            }
        }
    };
    this.tabEnnemi = [];
};

//CREATION des trois lignes d'ennemis
var ennemyOne = new Ennemy(window.document.getElementById('eShipOne'), [
    {left: 0, top: 0},
    {left: 160, top: 0},
    {left: 320, top: 0},
    {left: 480, top: 0},
    {left: 640, top: 0}]);
var ennemyTwo = new Ennemy(window.document.getElementById("eShipTwo"), [
    {left: 0, top: 100},
    {left: 160, top: 100},
    {left: 320, top: 100},
    {left: 480, top: 100},
    {left: 640, top: 100}]);
var ennemyThree = new Ennemy(window.document.getElementById("eShipThree"), [
    {left: 0, top: 200},
    {left: 160, top: 200},
    {left: 320, top: 200},
    {left: 480, top: 200},
    {left: 640, top: 200}]);



//DEPLACEMENT ENNEMIS

var eShipOne = document.getElementById('eShipOne');
var eShipTwo = document.getElementById('eShipTwo');
var eShipThree = document.getElementById('eShipThree');
eShipOne.style.left = '0px';
eShipTwo.style.left = '0px';
eShipThree.style.left = '0px';
eShipOne.style.top = '0px';
eShipTwo.style.top = '100px';
eShipThree.style.top = '200px';


//Deplacement vaisseaux ennemis en prenant en compte leur positions extrèmes
//Si gauche, deplacement vers droite jusqu'à droite, si droite déplacement vers bas;
//ensuite deplacement vers gauche puis bas et ainsi de suite
var checkIfRight = false;
var moveESpaceShip = function(){
    var styleShipOne = eShipOne.style;
    var styleShipTwo = eShipTwo.style;
    var styleShipThree = eShipThree.style;
    if(compteur === 126){
        sens = false;
        styleShipOne.top = parseInt(styleShipOne.top) + 10 + 'px';
        styleShipTwo.top = parseInt(styleShipTwo.top) + 10 + 'px';
        styleShipThree.top = parseInt(styleShipThree.top) + 10 + 'px';
        compteurTop = compteurTop +10;
    }else if (compteur === 0){
        sens = true;
        styleShipOne.top = parseInt(styleShipOne.top) + 10 + 'px';
        styleShipTwo.top = parseInt(styleShipTwo.top) + 10 + 'px';
        styleShipThree.top = parseInt(styleShipThree.top) + 10 + 'px';
        compteurTop = compteurTop +10;
    }
    if(sens){
        styleShipOne.left = parseInt(styleShipOne.left) + 1 + 'px';
        styleShipOne.left = 
        styleShipTwo.left = parseInt(styleShipTwo.left) + 1 + 'px';
        styleShipThree.left = parseInt(styleShipThree.left) + 1 + 'px';
        compteur++;
    }else{
        styleShipOne.left = parseInt(styleShipOne.left) - 1 + 'px';
        styleShipTwo.left = parseInt(styleShipTwo.left) - 1 + 'px';
        styleShipThree.left = parseInt(styleShipThree.left) - 1 + 'px';
        compteur--;
    }
};


//DEPLACEMENT VAISSEAU MERE
//Ecoute de l'evenement keydown pour window
//Gestion de la latence lors de l'utilisation des keydown et keyup par des boolléens

//Lorsqu'on press ENTER dans le tutoriel, le bouton change de couleur
window.addEventListener('keydown', function(event){
    keyEtat[event.keyCode] = true;
    switch(event.keyCode){
        case 13:
            pressEnter.style.backgroundColor = "#e5a228";
        break;
    }
});

window.addEventListener('keyup', function(event){
    keyEtat[event.keyCode] = false;
});

//DEPLACEMENT VAISSEAU MERE
//De base la vitesse de notre vaisseau est à 5, donc décrementation du left pour aller à gauche et incrémentation pour aller a droite
//Lorsque les touches sont préssées, le vaisseau "tourne" grçace à d'autres images
function movespaceship(){
    if(keyEtat[37]){
        spaceshipTableau.left -= vitesseVaisseau;
        drawSpaceship(spaceshipTableau.tableauPos[1]);
    }
    
    
    if(keyEtat[39]){
        spaceshipTableau.left += vitesseVaisseau;
        drawSpaceship(spaceshipTableau.tableauPos[3]);
    }
    
    //Limite deplacement spaceship au cadre (gauche / droite)
    //Lorsqu'on lache les touches de déplacement, le vaisseau reprend sa première image
    if((spaceshipTableau.left <= -3) || (spaceshipTableau.left >= 771)){
        if(keyEtat[37]){
            spaceshipTableau.left = -2;
            drawSpaceship(spaceshipTableau.tableauPos[0]);
        }

        if(keyEtat[39]){
            spaceshipTableau.left = 770;
            drawSpaceship(spaceshipTableau.tableauPos[0]);
        }
    }
    //attribution du left + "px" à mon vaisseau
    window.document.getElementById("spaceship").style.left = spaceshipTableau.left + "px";
    
};


//DESSIN SPACESHIP
//Deplacement d'un pixel pour chaque mouvement et pour chaque mouvement attribution de la seconde image au spaceship

window.document.onkeyup = function(event){

    switch(event.keyCode){
        case 37:
            drawSpaceship(spaceshipTableau.tableauPos[0]);
        break;
        case 39:
            drawSpaceship(spaceshipTableau.tableauPos[0]);
        break;
        case 13:
            //Lorsqu'on relache ENTER, le bouton reprend sa couleur normale, le tuto passe au second plan et le script se lance 
            pressEnter.style.backgroundColor = "#212121";
            tuton.style.zIndex = "-1";
            notutorial();
        break;
    }
};

function drawSpaceship(event){
    window.document.getElementById("spaceship").style.backgroundImage = event;
};


//MISSILE SPACESHIP

var SpaceshipBullet = function(src1, pos, explosion){ //fonction constructeur pour le missile
    this.src1 = src1;
    this.width = 9;
    this.height = 29;
    this.pos = pos;
    this.explosion = explosion;
    this.draw = function(){ //DESSIN MISSILE SPACESHIP
        this.src1.innerHTML = "";
        for(var i = 0; i < this.pos.length; i++){
            if(i < 2){ //limite de tir a 2
                this.src1.innerHTML += `<div class="bullet" style="left:${this.pos[i].left}px; top:${this.pos[i].top}px;"></div>`; 
            }
            else{
                this.pos.pop();
            }
        }
    };
    this.move = function(){ //DEPLACEMENT MISSILE
        for(var i = 0; i < this.pos.length; i++){
            this.pos[i].top = this.pos[i].top - 10;
            if(this.pos[i].top <= -29){
                this.pos.shift();
            }
        }
    };
};

var bullet = new SpaceshipBullet(window.document.getElementById('spaceshipBullet'), []);

window.document.onkeydown = function(event){
    switch(event.keyCode){
        case 32:
            bullet.pos.push({
                //position du vaisseau en fonction de la position du vaisseau
                left: spaceshipTableau.left + 27,
                top: spaceshipTableau.top - 28
            })
        break;
    }
};

//Fonction explosion
var boom = function(parent,position){ //utilisation de la seconde méthode qui ne doit pas faire crasher internet explorer(createElement, appendChild...)
    var explosion = document.createElement('img');
    parent.appendChild(explosion);
    explosion.style.position = 'absolute';
    explosion.style.top =  '0px';
    explosion.style.left = position[1] + 'px';
    explosion.style.zIndex = 2;
    var tabExplo = [
      './sprites/explosion/Explosion01.png',
      './sprites/explosion/Explosion02.png',
      './sprites/explosion/Explosion03.png',
      './sprites/explosion/Explosion04.png',
      './sprites/explosion/Explosion05.png',
      './sprites/explosion/Explosion06.png',
      './sprites/explosion/Explosion07.png',
      './sprites/explosion/Explosion08.png',
      './sprites/explosion/Explosion09.png'
    ];
    explosion.src = tabExplo[0]
    var i = 0;
  
    var anim = function(){
      var goAnim = setTimeout(anim,1000/25);
      explosion.src = tabExplo[i];
      i++
      if (i === 9) {
        clearTimeout(goAnim)
        parent.removeChild(explosion)
      }
    }
    anim()
};

//////////////GAME OVER/////////////////
var gameOver = function(){
    document.location.reload(true);
    boolo = true;
    tuton.style.zIndex = "1";
};

//Animation du texte GAME OVER 
var overGame = window.document.getElementById('overG');
var overG = function() {
    if(opacity2 <= 1){
        opacity2 = opacity2 + 0.01;
    }
    if(fontSize2 <= 240){
        fontSize2 = fontSize2 + 3;
    }
    overGame.style.fontSize = fontSize2 + 'px';
    overGame.style.opacity = opacity2;
};

//Lorsque soitle vaisseau touche les ennemis ou que les ennemis touchent le bas,
//Lancement de l'animation GAME OVER,
//On arrete le script et on relance le script qui n'est pas encore relancé, le tuto au premier plan 
var overGamer = function(){
    setInterval(overG, 15);
    clearInterval(intervalID);
    setTimeout(gameOver, 2700);
};


//COLLISIONS MISSILES

//PREMIER BLOC DE COLLISIONS ENTRE MISSILE ET ENNEMIS
//lorsque la position du missile et la position de l'ennemi coincide, disparition vaisseau ennemi et du missile,
//lancement explosion à la position de l'ennemi et score prend +1
function crashOne(ennemyOne){
    for(var comptCrashOne = 0; comptCrashOne < ennemyOne.pos.length; comptCrashOne++){
        for(var compt1 = 0; compt1 < bullet.pos.length; compt1++){
            if(ennemyOne.myShip['eShipOneenema' + comptCrashOne].alive){
                var positionX = ennemyOne.myShip['eShipOneenema' + comptCrashOne].x + compteur;
                var positionY = ennemyOne.myShip['eShipOneenema' + comptCrashOne].y + compteurTop;
            }else{
                var positionX = ennemyOne.myShip['eShipOneenema' + comptCrashOne].x - (ennemyOne.myShip['eShipOneenema' + comptCrashOne].x + compteur);
                var positionY = ennemyOne.myShip['eShipOneenema' + comptCrashOne].y - (ennemyOne.myShip['eShipOneenema' + comptCrashOne].y + compteurTop);
            }

            if(ennemyOne.myShip['eShipOneenema' + comptCrashOne].alive){
                if(bullet.pos[compt1].left > positionX && bullet.pos[compt1].left < positionX + 64 && bullet.pos[compt1].top > positionY && bullet.pos[compt1].top < positionY + 45){
                    bullet.pos.splice(compt1, 1);
                    ennemyOne.myShip['eShipOneenema' + comptCrashOne].alive = false;
                    document.getElementById('eShipOne').children[comptCrashOne].style.opacity = 0;
                    boom(ennemyOne.src,[ennemyOne.pos[comptCrashOne].top + 50 + compteurTop, ennemyOne.pos[comptCrashOne].left]);
                    score++;
                }
            }
        }
    }
};

function crashTwo(ennemyTwo){
    for(var comptCrashTwo = 0; comptCrashTwo < ennemyTwo.pos.length; comptCrashTwo++){
        for(var compt2 = 0; compt2 < bullet.pos.length; compt2++){
            if(ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].alive){
                var positionX = ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].x + compteur;
                var positionY = ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].y + compteurTop;
            }else{
                var positionX = ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].x - (ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].x + compteur);
                var positionY = ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].y - (ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].y + compteurTop);
            }

            if(ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].alive){
                if(bullet.pos[compt2].left > positionX && bullet.pos[compt2].left < positionX + 64 && bullet.pos[compt2].top > positionY && bullet.pos[compt2].top < positionY + 45){
                    bullet.pos.splice(compt2, 1);
                    ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].alive = false;
                    document.getElementById('eShipTwo').children[comptCrashTwo].style.opacity = 0;
                    boom(ennemyTwo.src,[ennemyTwo.pos[comptCrashTwo].top + 50 + compteurTop, ennemyTwo.pos[comptCrashTwo].left]);
                    score++;
                }
            }
        }
    }
};

function crashThree(ennemyThree){
    for(var comptCrashThree = 0; comptCrashThree < ennemyThree.pos.length; comptCrashThree++){
        for(var compt3 = 0; compt3 < bullet.pos.length; compt3++){
            if(ennemyThree.myShip['eShipThreeenema' + comptCrashThree].alive){
                var positionX = ennemyThree.myShip['eShipThreeenema' + comptCrashThree].x + compteur;
                var positionY = ennemyThree.myShip['eShipThreeenema' + comptCrashThree].y + compteurTop;
            }else{
                var positionX = ennemyThree.myShip['eShipThreeenema' + comptCrashThree].x - (ennemyThree.myShip['eShipThreeenema' + comptCrashThree].x + compteur);
                var positionY = ennemyThree.myShip['eShipThreeenema' + comptCrashThree].y - (ennemyThree.myShip['eShipThreeenema' + comptCrashThree].y + compteurTop);
            }

            if(ennemyThree.myShip['eShipThreeenema' + comptCrashThree].alive){
                if(bullet.pos[compt3].left > positionX && bullet.pos[compt3].left < positionX + 64 && bullet.pos[compt3].top > positionY && bullet.pos[compt3].top < positionY + 45){
                    bullet.pos.splice(compt3, 1);
                    ennemyThree.myShip['eShipThreeenema' + comptCrashThree].alive = false;
                    document.getElementById('eShipThree').children[comptCrashThree].style.opacity = 0;
                    boom(ennemyThree.src,[ennemyThree.pos[comptCrashThree].top + 50 + compteurTop, ennemyThree.pos[comptCrashThree].left]);
                    score++;
                }
            }
        }
    }
};


//COLLISIONS VAISSEAU ET ENNEMIS
//lorsque position vaisseau et ennemi coincide, disparition ennemi et vaisseau, et lancement fonction de fin du jeu
function crashGameOverOne(ennemyOne){
    for(var comptCrashOne = 0; comptCrashOne < ennemyOne.pos.length; comptCrashOne++){
        if(ennemyOne.myShip['eShipOneenema' + comptCrashOne].alive){
            var positionX = ennemyOne.myShip['eShipOneenema' + comptCrashOne].x + compteur;
            var positionY = ennemyOne.myShip['eShipOneenema' + comptCrashOne].y + compteurTop;
        }else{
            var positionX = ennemyOne.myShip['eShipOneenema' + comptCrashOne].x - (ennemyOne.myShip['eShipOneenema' + comptCrashOne].x + compteur);
            var positionY = ennemyOne.myShip['eShipOneenema' + comptCrashOne].y - (ennemyOne.myShip['eShipOneenema' + comptCrashOne].y + compteurTop);
        }
        if(ennemyOne.myShip['eShipOneenema' + comptCrashOne].alive){
            if(spaceshipTableau.left > positionX && spaceshipTableau.left < positionX + 64 && spaceshipTableau.top > positionY && spaceshipTableau.top < positionY + 45){
                ennemyOne.myShip['eShipOneenema' + comptCrashOne].alive = false;
                document.getElementById('eShipOne').children[comptCrashOne].style.opacity = 0;
                boom(window.document.getElementById('spaceship'), spaceshipTableau.top, spaceshipTableau.left);
                boom(ennemyOne.src,[ennemyOne.pos[comptCrashOne].top + 50 + compteurTop, ennemyOne.pos[comptCrashOne].left]);
                window.document.getElementById('spaceship').style.opacity = 0;
                if(window.document.getElementById('spaceship').style.opacity == 0){
                    overGamer();
                }
            }
        }
    }
};

function crashGameOverTwo(ennemyTwo){
    for(var comptCrashTwo = 0; comptCrashTwo < ennemyTwo.pos.length; comptCrashTwo++){
        if(ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].alive){
            var positionX = ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].x + compteur;
            var positionY = ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].y + compteurTop;
        }else{
            var positionX = ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].x - (ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].x + compteur);
            var positionY = ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].y - (ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].y + compteurTop);
        }
        if(ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].alive){
            if(spaceshipTableau.left > positionX && spaceshipTableau.left < positionX + 64 && spaceshipTableau.top > positionY && spaceshipTableau.top < positionY + 45){
                ennemyTwo.myShip['eShipTwoenema' + comptCrashTwo].alive = false;
                document.getElementById('eShipTwo').children[comptCrashTwo].style.opacity = 0;
                boom(window.document.getElementById('spaceship'), spaceshipTableau.top, spaceshipTableau.left);
                boom(ennemyTwo.src,[ennemyTwo.pos[comptCrashTwo].top + 50 + compteurTop, ennemyTwo.pos[comptCrashTwo].left]);
                window.document.getElementById('spaceship').style.opacity = 0;
                if(window.document.getElementById('spaceship').style.opacity == 0){
                    overGamer();
                }
            }
        }
    }
};

function crashGameOverThree(ennemyThree){
    for(var comptCrashThree = 0; comptCrashThree < ennemyThree.pos.length; comptCrashThree++){
        if(ennemyThree.myShip['eShipThreeenema' + comptCrashThree].alive){
            var positionX = ennemyThree.myShip['eShipThreeenema' + comptCrashThree].x + compteur;
            var positionY = ennemyThree.myShip['eShipThreeenema' + comptCrashThree].y + compteurTop;
        }else{
            var positionX = ennemyThree.myShip['eShipThreeenema' + comptCrashThree].x - (ennemyThree.myShip['eShipThreeenema' + comptCrashThree].x + compteur);
            var positionY = ennemyThree.myShip['eShipThreeenema' + comptCrashThree].y - (ennemyThree.myShip['eShipThreeenema' + comptCrashThree].y + compteurTop);
        }
        if(ennemyThree.myShip['eShipThreeenema' + comptCrashThree].alive){
            if(spaceshipTableau.left > positionX && spaceshipTableau.left < positionX + 64 && spaceshipTableau.top > positionY && spaceshipTableau.top < positionY + 45){
                ennemyThree.myShip['eShipThreeenema' + comptCrashThree].alive = false;
                document.getElementById('eShipThree').children[comptCrashThree].style.opacity = 0;
                boom(window.document.getElementById('spaceship'), spaceshipTableau.top, spaceshipTableau.left);
                boom(ennemyThree.src,[ennemyThree.pos[comptCrashThree].top + 50 + compteurTop, ennemyThree.pos[comptCrashThree].left]);
                window.document.getElementById('spaceship').style.opacity = 0;
                if(window.document.getElementById('spaceship').style.opacity == 0){
                    overGamer();
                }
            }
        }
    }
};

//COLLISIONS BOTTOM ET ENNEMIS
function crashBottomOne(ennemyOne){
    for(var comptCrashOne = 0; comptCrashOne < ennemyOne.pos.length; comptCrashOne++){
        if(document.getElementById('eShipOne').children[comptCrashOne]){
            if(compteurTop >= 450){
                overGamer();
            }
        }
    }
};

function crashBottomTwo(ennemyTwo){
    for(var comptCrashTwo = 0; comptCrashTwo < ennemyTwo.pos.length; comptCrashTwo++){
        if(document.getElementById('eShipTwo').children[comptCrashTwo]){
            if(compteurTop >= 350){
                overGamer();
            }
        }
    }
};

function crashBottomThree(ennemyThree){
    for(var comptCrashThree = 0; comptCrashThree < ennemyThree.pos.length; comptCrashThree++){
        if(document.getElementById('eShipThree').children[comptCrashThree]){
            if(compteurTop >= 250){
                overGamer();
            }
        }
    }
}

//LANCEMENT FONCTIONS
ennemyOne.draw();//dessin de la premiere ligne d'ennemi
ennemyTwo.draw();//dessin de la seconde
ennemyThree.draw();//dessin de la troisième

function spaceInvadersLap(){
    drawSpaceship();//dessin de mon vaisseau
    movespaceship();//deplacement de mon vaisseau
    moveESpaceShip();//deplacement des ennemis
    bullet.draw();//dessin des missiles
    bullet.move();//deplacement des missiles
    crashOne(ennemyOne);//collisions entre premiere ligne ennemis et vaisseau
    crashTwo(ennemyTwo);//collisions entre la seconde et vaisseau
    crashThree(ennemyThree);//collisions entre troisième et vaisseau
    crashGameOverOne(ennemyOne);//collisions entre vaisseau et premiere ligne ennemis
    crashGameOverTwo(ennemyTwo);//collisions entre vaisseau et la seconde
    crashGameOverThree(ennemyThree);//collisions entre vaisseau et la troisieme
    crashBottomOne(ennemyOne);//collisions entre bottom et premiere ligne ennemis
    crashBottomTwo(ennemyTwo);//collisions entre bottom et la seconde
    crashBottomThree(ennemyThree);//collisions entre bottom et la troisieme
    scoring();//fonction de scoring
};